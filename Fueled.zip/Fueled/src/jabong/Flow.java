package jabong;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import pages.HeaderLinksSection;
import pages.HomePage;
import pages.LoginModal;
import pages.ProductsPage;
import pages.QuickViewModal;
import pages.SearchForm;

public class Flow {
	
	private WebDriver driver;

	  private HomePage homePage;
//	  private ProductsPage productsPage;
//	  private  LoginModal loginModal ;
//	  private SearchForm searchForm;
//	  private QuickViewModal modal;
//	  private  HeaderLinksSection linksSection ;

	  Flow(WebDriver driver)
	  {
	    this.driver = driver;
	  }

	  void home()
	  {
	    homePage = PageFactory.initElements(driver, HomePage.class);
	  }

	  void openKurtaPage()
	  {

	    homePage.openKurtaPage();
	  }

	  void login(String handle, String passcode) throws InterruptedException
	  {
	    homePage.openLoginModal();
	    LoginModal loginModal = PageFactory.initElements(driver, LoginModal.class);
	    loginModal.submit(handle, passcode);
	  }

	  void addToWishList()
	  {
	    ProductsPage productsPage = PageFactory.initElements(driver, ProductsPage.class);
	    productsPage.addToWishList();
	  }

	  void search(String searchText, String size, int upto)
	  {
	    SearchForm searchForm = PageFactory.initElements(driver, SearchForm.class);
	    searchForm.search(searchText);
	    ProductsPage productsPage = PageFactory.initElements(driver, ProductsPage.class);

	    for (int i = 0; i < upto; i++) {
	      productsPage.openQuickLink(i);
	      QuickViewModal modal = PageFactory.initElements(driver, QuickViewModal.class);
	      modal.add(size);
	    }
	  }

	  void moveToCart()
	  {
	    HeaderLinksSection linksSection = PageFactory.initElements(driver, HeaderLinksSection.class);
	    linksSection.openWishList();

	  }

}
