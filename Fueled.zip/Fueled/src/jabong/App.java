package jabong;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class App
{
  private static final String HANDLE = "yeshu.manchanda@gmail.com";
  private static final String PASSCODE = "Welcome1";

  private static final String SEARCH_TEXT = "women black tops";
  private static final String SEARCH_SIZE = "S";
  private static final int MAX_ADD = 4;

  public static void main(String[] args) throws Exception
  {
   
	  ChromeOptions options = new ChromeOptions();
	  options.addArguments("--disable-notifications"); 
	  System.setProperty("webdriver.chrome.driver", "C:\\Zdrive\\share\\selenium training\\WebDriver\\DriverExes\\chromedriver.exe");
    
     
    WebDriver driver = new ChromeDriver(options);
    driver.manage().timeouts().pageLoadTimeout(5, TimeUnit.SECONDS);
    driver.manage().window().maximize();
    driver.get("https://jabong.com");

    Flow flow = new Flow(driver);
    try {
      flow.home();
      flow.login(HANDLE, PASSCODE); //403 coming
      flow.openKurtaPage();
      flow.addToWishList();

      flow.search(SEARCH_TEXT, SEARCH_SIZE, MAX_ADD);
      flow.moveToCart();
    } finally {
      Thread.sleep(100000);
      driver.quit();
    }
  }
}
