package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class HomePage extends AbstractPage {
	
	@FindBy(id = "signin-model-wishlist")
	  private WebElement login;

	  @FindBy(how = How.CSS, using = ".nav-women > a")
	  private WebElement womenLink;

	  @FindBy(xpath = "//*[@id=\"mainTopNav\"]/li[1]/div/div[3]/div[2]/a[2]")
	  private WebElement kurtaLink;

	  public HomePage(WebDriver driver)
	  {
	    super(driver);
	  }

	  public void openLoginModal()
	  {
	    login.click();
	  }

	  public void openKurtaPage()
	  {
	    System.out.println("Hello");
	    hoverWomenLink();
	    waitForVisibility(kurtaLink);
	    kurtaLink.click();
	  }

	  private void hoverWomenLink()
	  {
	    hover(womenLink);
	  }

}
