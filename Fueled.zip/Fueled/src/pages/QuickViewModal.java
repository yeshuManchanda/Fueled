package pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class QuickViewModal extends AbstractPage {
	
	private static final String ADD_TO_CART_BTN = "add-to-cart";

	  @FindBy(id = ADD_TO_CART_BTN)
	  private WebElement addToCartButton;

	  @FindBy(className = "size-button")
	  private List<WebElement> sizeButtons;

	  public QuickViewModal(WebDriver driver)
	  {
	    super(driver);
	    waitForpresence(By.id(ADD_TO_CART_BTN));
	  }

	  public void add(String size)
	  {
	    for (WebElement sizeButton : sizeButtons) {
	      if (size.equals(sizeButton.getAttribute("data-size"))) {
	        sizeButton.click();
	        break;
	      }
	    }

	    addToCartButton.click();

	    waitForNotificationDisappears();
	  }

	  private void waitForNotificationDisappears()
	  {
	    waitForVisibility(driver.findElement(By.className("cart-notification-container")));
	    waitForInvisibility(driver.findElement(By.className("cart-notification")));
	  }

}
