package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AbstractPage {
	
	private static final int TIMEOUT = 10;
	  private static final int POLL = 100;

	  WebDriver driver;

	  WebDriverWait wait;

	  AbstractPage(WebDriver driver)
	  {
	    this.driver = driver;
	    wait = new WebDriverWait(driver, TIMEOUT, POLL);
	    PageFactory.initElements(new AjaxElementLocatorFactory(driver, TIMEOUT), this);
	  }

	  void waitForVisibility(WebElement element) throws Error
	  {
	    wait.until(ExpectedConditions.visibilityOf(element));
	  }

	  void waitForInvisibility(WebElement element) throws Error
	  {
	    wait.until(ExpectedConditions.invisibilityOf(element));
	  }

	  void waitForpresence(By selector) throws Error
	  {
	    wait.until(ExpectedConditions.presenceOfElementLocated(selector));
	  }

	  void waitForClickable(WebElement element) throws Error
	  {
	    wait.until(ExpectedConditions.elementToBeClickable(element));
	  }

	  void hover(WebElement element)
	  {
	    Actions action = new Actions(driver);
	    action.moveToElement(element).perform();
	  }

}
