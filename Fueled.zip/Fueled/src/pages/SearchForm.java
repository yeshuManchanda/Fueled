package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class SearchForm extends AbstractPage{
	
	@FindBy(className = "top-search-input")
	  private WebElement searchContainer;

	  @FindBy(id = "search")
	  private WebElement searchInput;


	  public SearchForm(WebDriver driver)
	  {
	    super(driver);
	    waitForVisibility(searchContainer);
	  }

	  public void search(String searchText)
	  {
	    searchInput.sendKeys(searchText);
	    searchContainer.findElement(By.className("top-search-icon")).click();
	  }

}
