package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class HeaderLinksSection extends AbstractPage
{
	  @FindBy(how = How.CSS, using = "#header-like-sec > a")
	  private WebElement wishListLink;

	  @FindBy(how = How.CSS, using = "#header-bag-sec > a:nth-child(3)")
	  private WebElement cartLink;

	  public HeaderLinksSection(WebDriver driver)
	  {
	    super(driver);
	  }

	  public void openWishList()
	  {
	    waitForClickable(wishListLink);
	    wishListLink.click();
	  }

	  public void openCart()
	  {
	    cartLink.click();
	  }
	}
