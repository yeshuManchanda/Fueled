package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;


public class LoginModal extends AbstractPage {
	@FindBy(id = "login-email")
	  private WebElement email;

	  @FindBy(id = "login-pwd")
	  private WebElement password;

	  @FindBy(id = "btn-login")
	  private WebElement submit;

	  public LoginModal(WebDriver driver)
	  {
	    super(driver);
	    waitForVisibility(email);
	  }

	  public void submit(String handle, String passcode) throws InterruptedException
	  {
	    email.sendKeys(handle);
	    password.sendKeys(passcode);
	    submit.click();
	    waitForInvisibility(email);
	    System.out.println("Login Done");

}
}
