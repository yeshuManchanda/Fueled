package pages;



import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;



public class ProductsPage extends AbstractPage {
	  private static final String PRODUCTS_ITEM_SELECTOR = "#catalog-product > section.row.search-product.animate-products > div:nth-child(1)";

	  @FindBy(how = How.CSS, using = PRODUCTS_ITEM_SELECTOR)
	  private WebElement product;

	  @FindBy(className = "tile-cta")
	  private List<WebElement> items;


	  public ProductsPage(WebDriver driver)
	  {
	    super(driver);
	    waitForpresence(By.cssSelector(PRODUCTS_ITEM_SELECTOR));
	    waitForVisibility(product);
	    System.out.println("Product loaded");
	  }

	  public void addToWishList()
	  {
	    WebElement heart = product.findElement(By.className("wishlist"));

	    hover(heart);
	    heart.click();
	  }

	  public void openQuickLink(int index)
	  {
	    WebElement item = items.get(index);
	    waitForVisibility(item);
	    WebElement quickViewButton = item.findElement(By.className("quick-view"));
	    hover(item);
	    waitForVisibility(quickViewButton);
	    quickViewButton.click();
	  }


}
